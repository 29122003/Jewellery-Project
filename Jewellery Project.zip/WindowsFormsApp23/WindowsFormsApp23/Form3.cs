﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace WindowsFormsApp23
{
    public partial class Form3 : Form
    {

        OleDbConnection conn;
        OleDbCommand cmd;
        OleDbDataAdapter adapter;
        OleDbDataReader reader;
        DataTable dt;
        public Form3()
        {
            InitializeComponent();
        }
        void GetCustomer()
        {
            conn = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=\"C:\\Program Files\\Default Company Name\\Jewellery Setup\\Jewellery.accdb\"");
            dt = new DataTable();
            adapter = new OleDbDataAdapter("SELECT *FROM Customer", conn);
            conn.Open();
            adapter.Fill(dt);
            dataGridView1.DataSource = dt;
            conn.Close();

        }


        private void Form3_Load(object sender, EventArgs e)
        {
            GetCustomer();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void resetBtn_Click(object sender, EventArgs e)
        {
            idBox.Text = "";
            nameBox.Text = "";
            phoneBox.Text = "";
        }

        private void label3_Click(object sender, EventArgs e)
        {
            Form3 form3 = new Form3();
            form3.Show();
            this.Hide();
        }

        private void label4_Click(object sender, EventArgs e)
        {
            Form4 form = new Form4();
            form.Show();
            this.Hide();
        }

        private void label5_Click(object sender, EventArgs e)
        {
            Form5 form = new Form5();
            form.Show();
            this.Hide();
        }

        private void label7_Click(object sender, EventArgs e)
        {
            Form2 form = new Form2();
            form.Show();
            this.Hide();
        }

        private void insertBtn_Click(object sender, EventArgs e)
        {
            string query = "INSERT INTO Customer ([Name], [Phone]) " +
                 "VALUES (@name, @phone)";
            cmd=new OleDbCommand(query,conn);
           
            cmd.Parameters.AddWithValue("@name", nameBox.Text);
            cmd.Parameters.AddWithValue("@phone", phoneBox.Text);
            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();
            MessageBox.Show("INSERT DATA SUCCESSFULLY");
            GetCustomer();
        }

        private void dataGridView1_CellEnter(object sender, DataGridViewCellEventArgs e)
        {

            idBox.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            nameBox.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            phoneBox.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
        }

        private void updateBtn_Click(object sender, EventArgs e)
        {
            string query = "UPDATE Customer SET  [Name]=@name, [Phone]=@phone WHERE [ID]=@id ";
            OleDbCommand cmd = new OleDbCommand(query, conn);
             cmd.Parameters.AddWithValue("@name", nameBox.Text);
            cmd.Parameters.AddWithValue("@phone", phoneBox.Text);
            cmd.Parameters.AddWithValue("@id", Convert.ToInt32(idBox.Text));
               conn.Open();
                cmd.ExecuteNonQuery();
               
            MessageBox.Show("UPDATE SUCCESSFULLY");
            GetCustomer();
            conn.Close();
            

        }

        private void deleteBtn_Click(object sender, EventArgs e)
        {
            String query = "DELETE FROM Customer WHERE ID=@id";
            cmd = new OleDbCommand(query, conn);
            cmd.Parameters.AddWithValue("@id", Convert.ToInt32(idBox.Text));
            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();
            MessageBox.Show("DELETE SUCCESSFULLY");
            GetCustomer();
        }

        private void searchBox_TextChanged(object sender, EventArgs e)
        {
            OleDbConnection conn = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Jewellery.accdb");
            if (conn.State == ConnectionState.Closed)
                conn.Open();
            OleDbCommand cmd = new OleDbCommand("select id,Name,Phone from Customer where ID like'%" + searchBox.Text + "%'", conn);
            OleDbDataAdapter adapter = new OleDbDataAdapter();
            DataTable dt = new DataTable();
            adapter.SelectCommand = cmd;
            dt.Clear();
            adapter.Fill(dt);
            dataGridView1.DataSource = dt;
            conn.Close();
        }
    }
}
