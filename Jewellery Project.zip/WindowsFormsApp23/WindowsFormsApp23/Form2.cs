﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp23
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
            passwordBox.UseSystemPasswordChar = true;

        }
     
        private void LoginBtn_Click(object sender, EventArgs e)
        {
            if (userBox.Text == "" && passwordBox.Text == "")
            {
                MessageBox.Show("Missing Information");
            }
            else if( userBox.Text == "Admin" && passwordBox.Text == "12345")
            {
                MessageBox.Show("Login Successfully");
                Form3 form3 = new Form3();
                form3.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Please Enter Correct Username And Password");
            }
        }

        private void resetBtn_Click(object sender, EventArgs e)
        {

            userBox.Text = "";
            passwordBox.Text = "";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if(checkBox1.Checked)
            {
                passwordBox.UseSystemPasswordChar = false;
            }
            else
            {
                passwordBox.UseSystemPasswordChar = true;
            }
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }
    }
}
