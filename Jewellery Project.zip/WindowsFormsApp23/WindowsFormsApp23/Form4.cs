﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;


namespace WindowsFormsApp23
{
    public partial class Form4 : Form
    {
        OleDbConnection conn;
        OleDbCommand cmd;
        OleDbDataAdapter adapter;
        OleDbDataReader reader;
        DataTable dt;
        public Form4()
        {
            InitializeComponent();
        }
        void GetProduct()
        {
            conn = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=\"C:\\Program Files\\Default Company Name\\Jewellery Setup\\Jewellery.accdb\"");
            dt = new DataTable();
            adapter = new OleDbDataAdapter("SELECT *FROM Product", conn);
            conn.Open();
            adapter.Fill(dt);
            dataGridView1.DataSource = dt;
            conn.Close();
        }

        private void label3_Click(object sender, EventArgs e)
        {
            Form3 form = new Form3();
            form.Show();
            this.Hide();
        }

        private void label4_Click(object sender, EventArgs e)
        {
            Form4 form = new Form4();
            form.Show();
            this.Hide();
        }

        private void label5_Click(object sender, EventArgs e)
        {
            Form5 form = new Form5();   
            form.Show();
            this.Hide();

        }

        private void label7_Click(object sender, EventArgs e)
        {
            Form2 form = new Form2();
            form.Show(); 
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void resetBtn_Click(object sender, EventArgs e)
        {
            proidBox.Text = "";
            pronamecombo.Text = "";
            procatogerycombo.Text = "";
            quantityBox.Text = "";
            unitBox.Text = "";
        }

        private void insertBtn_Click(object sender, EventArgs e)
        {
            string query = "INSERT INTO Product ([Name], [Catogery], [Quantity], [UnitPrice])" +
                "VALUES (@name, @catogery, @quantity, @up)";
            cmd=new OleDbCommand(query,conn);
            cmd.Parameters.AddWithValue("@name", pronamecombo.Text);
            cmd.Parameters.AddWithValue("@catogery", procatogerycombo.Text);
            cmd.Parameters.AddWithValue("@quantity", quantityBox.Text);
            cmd.Parameters.AddWithValue("@up", unitBox.Text);
            conn.Open();
            cmd.ExecuteNonQuery();
            MessageBox.Show("INSERT DATA SUCCESSFULLY");
            GetProduct();
            conn.Close();
        }

        private void Form4_Load(object sender, EventArgs e)
        {
            GetProduct();
        }

        private void dataGridView1_CellEnter(object sender, DataGridViewCellEventArgs e)
        {

            proidBox.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            pronamecombo.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            procatogerycombo.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
            quantityBox.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();
             unitBox.Text = dataGridView1.CurrentRow.Cells[4].Value.ToString();
        }

        private void updateBtn_Click(object sender, EventArgs e)
        {
            string query = "UPDATE Product SET [Name]=@name, [Catogery]=@catogery, [Quantity]=@quantity, [UnitPrice]=@up WHERE [ID]=@id";
           OleDbCommand cmd=new OleDbCommand(query,conn);
            cmd.Parameters.AddWithValue("@name", pronamecombo.Text);
            cmd.Parameters.AddWithValue("@catogery", procatogerycombo.Text);
            cmd.Parameters.AddWithValue("@quantity", quantityBox.Text);
            cmd.Parameters.AddWithValue("@up", unitBox.Text);
            cmd.Parameters.AddWithValue("@id", Convert.ToInt32(proidBox.Text));
            conn.Open();
            cmd.ExecuteNonQuery();
            MessageBox.Show("UPDATE DATA SUCCESSFULLY");
            GetProduct();   
            conn.Close();
        }

        private void deleteBtn_Click(object sender, EventArgs e)
        {
            string query = "DELETE FROM Product WHERE ID=@id";
            cmd = new OleDbCommand(query, conn);
            cmd.Parameters.AddWithValue("@id", Convert.ToInt32(proidBox.Text));
            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();
            MessageBox.Show("DELETE SUCCESSFULLY");
            GetProduct();
        }

        private void searchBox_TextChanged(object sender, EventArgs e)
        {
            OleDbConnection conn = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Jewellery.accdb");
            if (conn.State == ConnectionState.Closed)
                conn.Open();
            OleDbCommand cmd = new OleDbCommand("select id,Name,Catogery,Quantity,UnitPrice from Product where ID like'%" + searchBox.Text + "%'", conn);
            OleDbDataAdapter adapter = new OleDbDataAdapter();
            DataTable dt = new DataTable();
            adapter.SelectCommand = cmd;
            dt.Clear();
            adapter.Fill(dt);
            dataGridView1.DataSource = dt;
            conn.Close();
        }
    }
}
